'''
Created on Mar 16, 2018

@author: berryme@yahoo.com
'''

from lxml import etree


class FindElement(object):
    '''
    classdocs
    '''
    pullParser = etree.XMLPullParser()



    def __init__(self, xmlDoc):
        '''
        Constructor
        '''
        self.xml = xmlDoc
        # self.tree = pullP

    def find(aString):
        pass
        # FindElement.pullParser.
