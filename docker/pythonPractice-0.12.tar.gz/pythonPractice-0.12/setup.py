from setuptools import setup

setup(
    name='pythonPractice',
    version='0.12',
    packages=['web', 'web.web', 'web.tests', 'web.packages', 'web.packages.xml', 'libs', 'libs.xml', 'web1', 'web1.web1',
              'polls', 'polls.polls'],
    url='',
    license='',
    author='berryme',
    author_email='',
    description='practice wheel'
)
